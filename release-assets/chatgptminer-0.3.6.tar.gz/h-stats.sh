#!/usr/bin/env bash

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)
if [[ -f "$SCRIPT_DIR/h-manifest.conf" ]]; then
  # shellcheck disable=SC1090
  . "$SCRIPT_DIR/h-manifest.conf"
fi

CONFIG_FILE="${RGMINER_CONFIG:-${SCRIPT_DIR}/config.env}"
if [[ -f "$CONFIG_FILE" ]]; then
  # shellcheck disable=SC1090
  . "$CONFIG_FILE" 2>/dev/null || true
fi

API_HOST="${API_HOST:-127.0.0.1}"
API_PORT="${API_PORT:-${CUSTOM_API_PORT:-9200}}"
ALGO_VALUE="${STATS_ALGO:-${ALGO:-}}"
# Canonical selection overrides stale flight-sheet defaults.
case "${ALGO,,}" in
  zkpow|zk|nock|nockchain|nock-zk|nock_zk|nock-zk-v5) ALGO_VALUE=zkpow ;;
  quantus|qtc|poseidon2|poseidon-2|poseidon_2) ALGO_VALUE=quantus ;;
esac
VERSION_VALUE="${CUSTOM_VERSION:-}"
GPU_STATS_FILE="${GPU_STATS_JSON:-/run/hive/gpu-stats.json}"
API_PORTS_FILE="${API_PORTS_FILE:-/tmp/rgminer_api_ports}"

# Keep CLI selectors internal. HiveOS receives the public algorithm names used
# by pools and flight sheets.
case "${ALGO_VALUE,,}" in
  pearl) ALGO_VALUE="pearlhash" ;;
  zkpow|zk|nock|nockchain|nock-zk|nock_zk|nock-zk-v5) ALGO_VALUE="zkpow" ;;
  quantus|qtc|poseidon2|poseidon-2|poseidon_2) ALGO_VALUE="quantus" ;;
esac

json_escape() {
  local value="${1-}"
  value=${value//\\/\\\\}
  value=${value//\"/\\\"}
  value=${value//$'\n'/\\n}
  value=${value//$'\r'/\\r}
  value=${value//$'\t'/\\t}
  printf '%s' "$value"
}

finish_stats() {
  khs="${1:-0}"
  stats="${2:-null}"
  if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    echo "$khs"
    echo "$stats"
    exit 0
  fi
  return 0
}

read_api_routes() {
  local raw token
  if [[ -r "$API_PORTS_FILE" ]]; then
    raw=$(tr ';\n' '  ' <"$API_PORTS_FILE" 2>/dev/null || true)
  fi
  if [[ -z "${raw:-}" ]]; then
    raw="$API_PORT"
  fi
  for token in $raw; do
    if [[ "$token" =~ ^([0-9]+)=([0-9]+(,[0-9]+)*)$ ]]; then
      printf '%s|%s\n' "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}"
    elif [[ "$token" =~ ^[0-9]+$ ]]; then
      printf '%s|\n' "$token"
    fi
  done
}

api_json=""
if command -v curl >/dev/null 2>&1 && command -v jq >/dev/null 2>&1; then
  api_payloads=()
  while IFS='|' read -r port device_map; do
    [[ -n "$port" ]] || continue
    payload=$(curl -s --max-time 2 "http://${API_HOST}:${port}/metrics" 2>/dev/null || true)
    if [[ -n "$payload" ]] && printf '%s' "$payload" | jq -e . >/dev/null 2>&1; then
      if [[ -n "${device_map:-}" ]]; then
        payload=$(printf '%s' "$payload" | jq -c --arg map "$device_map" '
          ($map | split(",") | map(tonumber)) as $physical |
          .miners = ((.miners // []) | map(
            (.deviceId | tonumber? // 0) as $local |
            .deviceId = ($physical[$local] // $local)))' 2>/dev/null || true)
      fi
      api_payloads+=("$payload")
    fi
  done < <(read_api_routes)
  if ((${#api_payloads[@]})); then
    api_json=$(printf '%s\n' "${api_payloads[@]}" |
      jq -cs '{miners: ([.[] | .miners // []] | add // [])}' 2>/dev/null || true)
  fi
fi

gpu_stats_json="{}"
if [[ -r "$GPU_STATS_FILE" ]]; then
  gpu_stats_json=$(cat "$GPU_STATS_FILE" 2>/dev/null || printf '{}')
fi
if ! printf '%s' "$gpu_stats_json" | jq -e . >/dev/null 2>&1; then
  gpu_stats_json="{}"
fi

if [[ -n "$api_json" ]] && command -v jq >/dev/null 2>&1; then
  stats=$(printf '%s' "$api_json" | jq -c \
    --arg ver "$VERSION_VALUE" \
    --arg algo "$ALGO_VALUE" \
    --argjson gpu "$gpu_stats_json" '
    def number_or_zero: tonumber? // 0;
    def rate_hs: (.emaRate | number_or_zero);
    def hex_digit:
      ascii_downcase
      | if . == "0" then 0
        elif . == "1" then 1
        elif . == "2" then 2
        elif . == "3" then 3
        elif . == "4" then 4
        elif . == "5" then 5
        elif . == "6" then 6
        elif . == "7" then 7
        elif . == "8" then 8
        elif . == "9" then 9
        elif . == "a" then 10
        elif . == "b" then 11
        elif . == "c" then 12
        elif . == "d" then 13
        elif . == "e" then 14
        elif . == "f" then 15
        else 0 end;
    def hex_byte:
      if type == "string" and length >= 2 then
        ((.[0:1] | hex_digit) * 16) + (.[1:2] | hex_digit)
      else
        0
      end;
    def bus_number:
      (.pciBusId // ""
       | capture("^[0-9A-Fa-f]+:(?<bus>[0-9A-Fa-f]{2}):")?
       | .bus? // empty
       | hex_byte) // 0;
    def short_bus_number:
      (. // ""
       | capture("^(?<bus>[0-9A-Fa-f]{2}):")?
       | .bus? // empty
       | hex_byte) // 0;
    def telemetry_for_bus($bus):
      ($gpu.busids // []) as $busids |
      ([range(0; ($busids | length))
        | select(($busids[.] | short_bus_number) == $bus)] | first) as $idx |
      if $idx == null then
        {temp: 0, fan: 0, power: 0}
      else
        {
          temp: (($gpu.temp[$idx] // 0) | number_or_zero),
          fan: (($gpu.fan[$idx] // 0) | number_or_zero),
          power: (($gpu.power[$idx] // 0) | number_or_zero)
        }
      end;
    def miner_row: {
      bus: bus_number
    } as $base |
    telemetry_for_bus($base.bus) as $telemetry |
    $base + {
      deviceId: (.deviceId | number_or_zero),
      khs: (rate_hs / 1000),
      gh: (rate_hs / 1000000000),
      accepted: (.acceptedShares | number_or_zero),
      rejected: (.rejectedShares | number_or_zero),
      stale: (.staleShares | number_or_zero),
      temp: $telemetry.temp,
      fan: $telemetry.fan,
      power: $telemetry.power,
      uptimeMs: (.processUptimeMs | number_or_zero),
      status: (.lastStatus // "")
    };
    (.miners // [] | map(select(type == "object") | miner_row) | sort_by(.deviceId)) as $miners |
    ($miners | map(.khs)) as $rates |
    ($miners | map(.gh)) as $gh_rates |
    ($miners | map(.accepted)) as $accepted |
    ($miners | map(.rejected)) as $rejected |
    ($miners | map(.stale)) as $stale |
    ($miners | map(.bus)) as $bus_numbers |
    ($miners | map(.temp)) as $temp |
    ($miners | map(.fan)) as $fan |
    ($miners | map(.power)) as $power |
    ($miners | map(.uptimeMs) | max // 0) as $uptime_ms |
    ($rates | add // 0) as $total_khs |
    ($gh_rates | add // 0) as $total_gh |
    {
      status: (if ($miners | length) > 0 then "running" else "unknown" end),
      khs: $rates,
      hs: $rates,
      hs_units: "khs",
      hs_gh: $gh_rates,
      temp: $temp,
      fan: $fan,
      power: $power,
      bus_numbers: $bus_numbers,
      uptime: (($uptime_ms / 1000) | floor),
      ver: $ver,
      ar: [($accepted | add // 0), ($rejected | add // 0)],
      accepted_shares: ($accepted | add // 0),
      rejected_shares: ($rejected | add // 0),
      stale_shares: ($stale | add // 0),
      accepted: $accepted,
      rejected: $rejected,
      stale: $stale,
      total_khs: $total_khs,
      total_gh: $total_gh
    } | if $algo == "" then . else . + {algo: $algo} end' 2>/dev/null || true)
  if [[ -n "$stats" ]] && printf '%s' "$stats" | jq -e . >/dev/null 2>&1; then
    total=$(printf '%s' "$stats" | jq -r '.total_khs // 0' 2>/dev/null || echo 0)
    finish_stats "$total" "$stats"
    return 0 2>/dev/null || exit 0
  fi
fi

ver_json=$(json_escape "$VERSION_VALUE")
algo_json=$(json_escape "$ALGO_VALUE")
fallback_stats=$(printf '{"status":"unknown","khs":[],"hs":[],"hs_units":"khs","hs_gh":[],"temp":[],"fan":[],"bus_numbers":[],"uptime":0,"ver":"%s","ar":[0,0],"accepted_shares":0,"rejected_shares":0,"stale_shares":0,"accepted":[],"rejected":[],"stale":[],"total_khs":0,"total_gh":0' "$ver_json")
if [[ -n "$ALGO_VALUE" ]]; then
  fallback_stats="${fallback_stats},\"algo\":\"${algo_json}\""
fi
fallback_stats="${fallback_stats}}"
finish_stats "0" "$fallback_stats"
return 0 2>/dev/null || exit 0
