#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
LOG_FILE="/tmp/h_run_launch.log"
CONF_FILE="${RGMINER_CONFIG:-${SCRIPT_DIR}/config.env}"

if [[ -f "$CONF_FILE" ]]; then
  # shellcheck disable=SC1090
  . "$CONF_FILE"
fi

sanitize_internal_runtime_flags() {
  local rgm_var
  while IFS= read -r rgm_var; do
    case "$rgm_var" in
      RGM_PEARL_BATCHED_HASH_THREADS|RGM_PEARL_SHARE_DIFF|RGM_WATCHDOG_POLICY)
        ;;
      *)
        unset "$rgm_var"
        ;;
    esac
  done < <(compgen -v RGM_)
  unset EXFER_CPU_VERIFY_SHARES
}

sanitize_internal_runtime_flags

while IFS= read -r rgm_var; do
  [[ -n "$rgm_var" ]] && export "$rgm_var"
done < <(compgen -v RGM_)

# Launch parameters an owner approved through the panel. The launcher writes this
# file before it rebuilds the backends, so every later start has to rebuild the
# same command line from it; deleting the file returns the rig to the flight
# sheet above. It is sourced after the sanitizer so its RGM_* markers survive.
MANAGED_CONFIG_FILE="${SCRIPT_DIR}/rgminer_managed_config.env"
if [[ -f "$MANAGED_CONFIG_FILE" ]]; then
  # shellcheck disable=SC1090
  . "$MANAGED_CONFIG_FILE"
  # The document names the protocol its pools speak; the flight sheet's own
  # PEARL_PROTOCOL keeps its value when the document does not restate pools.
  if [[ "${POOL_PROTOCOL+x}" == x ]]; then
    PEARL_PROTOCOL="$POOL_PROTOCOL"
    PROTO="$POOL_PROTOCOL"
  fi
  printf '[h-run] managed configuration from %s\n' "$MANAGED_CONFIG_FILE" \
    >>"$LOG_FILE"
fi

: "${API_HOST:=127.0.0.1}"
: "${API_PORT:=9200}"
: "${PROTO:=}"
: "${WATCHDOG:=0}"
: "${WATCHDOG_POLICY:=}"
: "${INSTALL_CMP_DRIVER:=0}"

# shellcheck source=h-driver.sh
. "${SCRIPT_DIR}/h-driver.sh"

trim_value() {
  local value="${1-}"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

bool_enabled() {
  local raw="${1:-}"
  local value="${raw,,}"
  [[ "$value" =~ ^(1|true|yes|on|y|enable|enabled)$ ]]
}

apply_wallet_worker_suffix() {
  local raw base suffix
  raw=$(trim_value "$ADDRESS")
  [[ "$raw" == *.* ]] || return 0
  base="${raw%.*}"
  suffix="${raw##*.}"
  [[ -n "$base" && -n "$suffix" ]] || return 0
  ADDRESS="$base"
  if (( WORKER_NAME_EXPLICIT == 0 )); then
    WORKER_NAME="$suffix"
  fi
}

bool_disabled() {
  local raw="${1:-}"
  local value="${raw,,}"
  [[ "$value" =~ ^(0|false|no|off|n|disable|disabled)$ ]]
}

normalize_watchdog_policy() {
  local raw="${1:-}"
  local fallback="${2:-}"
  local value
  raw=$(trim_value "$raw")
  value="${raw,,}"
  case "$value" in
    restart|restarting)
      printf 'restart'
      ;;
    reboot|rebooting)
      printf 'reboot'
      ;;
    notify|message|message-only|log|log-only|none|off|0|false|no|disable|disabled|"")
      if [[ -z "$value" && -n "$fallback" ]]; then
        printf '%s' "$fallback"
      else
        printf 'notify'
      fi
      ;;
    *)
      echo "[h-run] WARN: invalid WATCHDOG_POLICY='$raw'; using restart" >>"$LOG_FILE"
      printf 'restart'
      ;;
  esac
}

send_watchdog_message() {
  local suffix="${1:-}"
  local message="CUDA GPU failure detected"
  if [[ -n "$suffix" ]]; then
    message+=" $suffix"
  fi
  echo "[h-run] WARN: $message" >>"$LOG_FILE"
  if bool_enabled "${HIVE_MESSAGE_DISABLE:-0}"; then
    return 0
  fi
  if [[ -x /hive/bin/message ]]; then
    /hive/bin/message danger "$message" >/dev/null 2>&1 || true
  elif command -v message >/dev/null 2>&1; then
    message danger "$message" >/dev/null 2>&1 || true
  fi
}

send_unlocker_message() {
  local status="$1" message severity="ok"
  case "$status" in
    not_required|installed) return 0 ;;
    preparing) message="CMP unlock: preparing and building driver. Please wait; do not reboot manually." ;;
    downloading) message="CMP unlock: downloading files" ;;
    installing) message="CMP unlock: reboot scheduled" ;;
    reboot_required) message="CMP unlock: reboot scheduled" ;;
    open_kernels_required) message="CMP unlock: NVIDIA Open Kernel Modules are required"; severity="danger" ;;
    error) message="CMP unlock failed; check miner log"; severity="danger" ;;
    *) return 0 ;;
  esac
  message="[RG] $message"
  printf '[RG] %s [h-run] %s\n' "$(date '+%Y-%m-%d %H:%M:%S%z')" "${message#'[RG] '}" >>"$LOG_FILE"
  bool_enabled "${HIVE_MESSAGE_DISABLE:-0}" && return 0
  local rc=127
  if [[ -x /hive/bin/message ]]; then
    if timeout 55 /hive/bin/message "$severity" "$message" >/dev/null 2>&1; then rc=0; else rc=$?; fi
  elif command -v message >/dev/null 2>&1; then
    if timeout 55 message "$severity" "$message" >/dev/null 2>&1; then rc=0; else rc=$?; fi
  fi
  printf '[RG] %s [h-run] notification status=%s delivery_rc=%s\n' \
    "$(date '+%Y-%m-%d %H:%M:%S%z')" "$status" "$rc" >>"$LOG_FILE"
  if [[ "$status" == reboot_required && "$rc" == 0 && -n "${Q_8a7be0c930b54fca91ad:-}" ]]; then
    printf 1 > "$Q_8a7be0c930b54fca91ad"
  fi
  return "$rc"
}

watch_unlocker_status() {
  local watched_pid="$1" api_probe_host="$API_HOST"
  local payload status tick_pid previous="" event_id event_status cursor=0
  local -a message_pids=()
  local -A notified=()
  if [[ "$api_probe_host" == "0.0.0.0" || "$api_probe_host" == "::" ]]; then
    api_probe_host="127.0.0.1"
  elif [[ "$api_probe_host" == *:* && "$api_probe_host" != \[*\] ]]; then
    api_probe_host="[$api_probe_host]"
  fi
  command -v curl >/dev/null 2>&1 || return 0
  command -v jq >/dev/null 2>&1 || return 0
  while kill -0 "$watched_pid" 2>/dev/null; do
    sleep 1 &
    tick_pid=$!
    payload=$(curl -fsS --connect-timeout 0.5 --max-time 0.8 \
      "http://${api_probe_host}:${API_PORT}/unlocker" 2>/dev/null || true)
    status=$(printf '%s' "$payload" | jq -er '.status | select(type == "string")' 2>/dev/null || true)
    # Replay transitions missed between polls; retain compatibility with older miners.
    while IFS=$'\t' read -r event_id event_status; do
      [[ "$event_id" =~ ^[0-9]+$ && ${#event_id} -le 15 ]] || continue
      (( event_id > cursor )) || continue
      cursor=$event_id
      if [[ -z "${notified[$event_status]:-}" ]]; then
        send_unlocker_message "$event_status" &
        message_pids+=("$!")
        notified[$event_status]=1
      fi
      previous="$event_status"
    done < <(printf '%s' "$payload" | jq -r '.events[]? | select((.id | type) == "number" and (.status | type) == "string") | [.id, .status] | @tsv' 2>/dev/null || true)
    if [[ -n "$status" && -z "${notified[$status]:-}" ]]; then
      send_unlocker_message "$status" &
      message_pids+=("$!")
      notified[$status]=1
      previous="$status"
    fi
    wait "$tick_pid" 2>/dev/null || true
    # Reap finished senders without blocking the next API poll.
    local -a active_pids=()
    local pid
    for pid in "${message_pids[@]}"; do
      if kill -0 "$pid" 2>/dev/null; then active_pids+=("$pid")
      else wait "$pid" 2>/dev/null || true; fi
    done
    message_pids=("${active_pids[@]}")
    [[ "$status" == installed || "$status" == not_required ]] && break
  done
  for pid in "${message_pids[@]}"; do wait "$pid" 2>/dev/null || true; done
}

stop_unlocker_watcher() {
  if [[ -n "${unlocker_watcher_pid:-}" ]]; then
    kill -TERM "$unlocker_watcher_pid" 2>/dev/null || true
    wait "$unlocker_watcher_pid" 2>/dev/null || true
    unlocker_watcher_pid=""
  fi
}

format_watchdog_api_errors() {
  jq -r '
    [.miners[]? |
     select((.lastStatus // "") == "ERROR") |
     ((.pciBusId // "") | tostring) as $raw_pci |
     (if $raw_pci == "" then
        "unknown"
      elif ($raw_pci |
        test("^[0-9A-Fa-f]{4,8}:[0-9A-Fa-f]{2}:[0-9A-Fa-f]{2}\\.[0-7]$")) then
        ($raw_pci | sub("^[0-9A-Fa-f]{4,8}:"; ""))
      else
        $raw_pci
      end) as $pci |
     "GPU \(.deviceId // "?") PCI \($pci)"] |
    .[]'
}

watch_api_errors() {
  local watched_pid="$1"
  local api_probe_host="$API_HOST"
  local payload current previous="" line
  if [[ "$api_probe_host" == "0.0.0.0" || "$api_probe_host" == "::" ]]; then
    api_probe_host="127.0.0.1"
  fi
  command -v curl >/dev/null 2>&1 || return 0
  command -v jq >/dev/null 2>&1 || return 0
  while kill -0 "$watched_pid" 2>/dev/null; do
    payload=$(curl -s --max-time 1 \
      "http://${api_probe_host}:${API_PORT}/metrics" 2>/dev/null || true)
    current=$(printf '%s' "$payload" |
      format_watchdog_api_errors 2>/dev/null || true)
    if [[ -n "$current" && "$current" != "$previous" ]]; then
      while IFS= read -r line; do
        [[ -n "$line" ]] || continue
        if ! grep -Fqx -- "$line" <<<"$previous"; then
          send_watchdog_message "$line"
        fi
      done <<<"$current"
    fi
    previous="$current"
    sleep 0.5
  done
}

request_watchdog_reboot() {
  sync >/dev/null 2>&1 || true
  if command -v reboot >/dev/null 2>&1; then
    reboot >/dev/null 2>&1 || true
  elif [[ -x /sbin/reboot ]]; then
    /sbin/reboot >/dev/null 2>&1 || true
  elif command -v systemctl >/dev/null 2>&1; then
    systemctl reboot -i >/dev/null 2>&1 || true
  fi
}

handle_watchdog_exit() {
  local scope="${1:-miner}"
  case "$WATCHDOG_POLICY_NORMALIZED" in
    restart)
      send_watchdog_message "restarting"
      echo "[h-run] WARN: $scope exited after CUDA GPU failure; restarting, rgminer will exclude watchdog-disabled GPUs" >>"$LOG_FILE"
      return 0
      ;;
    reboot)
      send_watchdog_message "rebooting"
      echo "[h-run] WARN: $scope exited after CUDA GPU failure; rebooting rig" >>"$LOG_FILE"
      request_watchdog_reboot
      return 1
      ;;
    *)
      send_watchdog_message
      echo "[h-run] WARN: $scope exited after CUDA GPU failure; watchdog policy notify exits without restart" >>"$LOG_FILE"
      return 1
      ;;
  esac
}

normalize_algo() {
  local value="${1:-}"
  value="${value,,}"
  case "$value" in
    pearl|prl|pearlhash|pearl-hash|pearl_hash)
      printf 'pearl'
      ;;
    exfer|argon2id|exfer_argon2id|exfer-argon2|exfer-argon2id)
      printf 'exfer-argon2id'
      ;;
    quantus|qtc|poseidon2|poseidon-2|poseidon_2)
      printf 'quantus'
      ;;
    zkpow|zk|nock|nockchain|nock-zk|nock_zk|nock-zk-v5)
      printf 'nock-zk'
      ;;
    blake2b)
      printf 'blake2b'
      ;;
    "")
      printf 'pearl'
      ;;
    *)
      printf '%s' "$value"
      ;;
  esac
}

normalize_stratum_tls() {
  local value="${1:-auto}"
  value=$(trim_value "$value")
  value="${value,,}"
  case "$value" in
    ""|auto) printf 'auto' ;;
    tls|ssl|on|true|1) printf 'tls' ;;
    tcp|off|false|0) printf 'tcp' ;;
    verify|tls-verify) printf 'verify' ;;
    insecure|tls-insecure) printf 'insecure' ;;
    *)
      echo "[h-run] WARN: invalid STRATUM_TLS='$value'; using auto" >>"$LOG_FILE"
      printf 'auto'
      ;;
  esac
}

miner_watchdog_policy() {
  case "$WATCHDOG_POLICY_NORMALIZED" in
    restart|reboot) printf '%s' "$WATCHDOG_POLICY_NORMALIZED" ;;
    *) printf 'off' ;;
  esac
}

append_endpoint_args() {
  local raw="${1:-}"
  local fallback="${2:-}"
  local endpoint
  raw="${raw//,/ }"
  raw="${raw//;/ }"
  if [[ -z "$raw" && -n "$fallback" ]]; then
    raw="$fallback"
  fi
  for endpoint in $raw; do
    endpoint=$(trim_value "$endpoint")
    if [[ "${STRATUM_TLS_MODE:-auto}" == tcp ]]; then
      case "$endpoint" in
        stratum+tcp://*) ;;
        *://*)
          echo "[h-run] ERROR: STRATUM_TLS=tcp conflicts with pool URL scheme; refusing protocol downgrade" >&2
          return 1
          ;;
        *) endpoint="stratum+tcp://$endpoint" ;;
      esac
    fi
    [[ -n "$endpoint" ]] && ARGS+=(--stratum "$endpoint")
  done
}

validate_and_append_devices() {
  local raw="${1:-}"
  local normalized
  local token
  [[ -n "$(trim_value "$raw")" ]] || return 0
  normalized="${raw//,/ }"
  normalized="${normalized//;/ }"
  local count=0
  for token in $normalized; do
    if [[ ! "$token" =~ ^[0-9]+$ ]]; then
      echo "[h-run] ERROR: invalid DEVICES token '$token'" >>"$LOG_FILE"
      return 1
    fi
    count=$((count + 1))
  done
  if ((count == 0)); then
    echo "[h-run] ERROR: DEVICES must contain at least one GPU index" >>"$LOG_FILE"
    return 1
  fi
  ARGS+=(-d "$raw")
}

append_pearl_share_diff_args() {
  local raw="${1:-}"
  local value
  raw=$(trim_value "$raw")
  value="${raw,,}"
  [[ "$MINER_ALGO" == "pearl" ]] || return 0
  case "$value" in
    "")
      ;;
    auto)
      ARGS+=(--pearl-share-diff auto)
      ;;
    off|none|disable|disabled|false|0|no)
      ARGS+=(--pearl-share-diff off)
      ;;
    *)
      if [[ "$raw" =~ ^[1-9][0-9]*$ ]]; then
        ARGS+=(--pearl-share-diff "$raw")
      else
        echo "[h-run] WARN: ignoring invalid PEARL_SHARE_DIFF '$raw'" >>"$LOG_FILE"
      fi
      ;;
  esac
}

export_pearl_batched_hash_threads() {
  local raw="${1:-}"
  raw=$(trim_value "$raw")
  case "$raw" in
    ""|auto|AUTO|Auto)
      ;;
    64|128|256|512|1024)
      export RGM_PEARL_BATCHED_HASH_THREADS="$raw"
      ;;
    *)
      echo "[h-run] WARN: ignoring invalid PEARL_BATCHED_HASH_THREADS '$raw'" >>"$LOG_FILE"
      ;;
  esac
}

append_extra_args() {
  local raw="${1:-}"
  local token
  local -a extra=()
  while IFS= read -r line; do
    for token in $line; do
      [[ -n "$token" ]] && extra+=("$token")
    done
  done <<<"$raw"
  local i
  for ((i=0; i<${#extra[@]}; ++i)); do
    case "${extra[$i],,}" in
      --algo=*|--algorithm=*)
        extra[$i]="${extra[$i]%%=*}=$(normalize_algo "${extra[$i]#*=}")"
        ;;
      --algo|--algorithm)
        if ((i+1<${#extra[@]})); then
          extra[$((i+1))]=$(normalize_algo "${extra[$((i+1))]}")
          i=$((i+1))
        fi
        ;;
    esac
  done
  if ((${#extra[@]})); then
    ARGS+=("${extra[@]}")
  fi
}

WORKER_NAME=$(trim_value "${WORKER_NAME:-${CUSTOM_WORKER_NAME:-}}")
WORKER_NAME_EXPLICIT=0
if [[ -n "$WORKER_NAME" ]]; then
  WORKER_NAME_EXPLICIT=1
else
  WORKER_NAME=$(hostname 2>/dev/null || printf 'rgminer')
fi

MINER_ALGO=$(normalize_algo "${ALGO:-${CUSTOM_ALGO:-}}")
ADDRESS=$(trim_value "${ADDRESS:-${WALLET:-}}")
apply_wallet_worker_suffix
POOLS_VALUE="${POOLS:-}"
WATCHDOG_VALUE="${WATCHDOG:-${RGMINER_WATCHDOG:-1}}"
WATCHDOG_POLICY_VALUE="${WATCHDOG_POLICY:-${RGM_WATCHDOG_POLICY:-${RGMINER_WATCHDOG_POLICY:-}}}"
WATCHDOG_POLICY_FALLBACK="restart"
WATCHDOG_POLICY_NORMALIZED=$(normalize_watchdog_policy "$WATCHDOG_POLICY_VALUE" "$WATCHDOG_POLICY_FALLBACK")
MINER_WATCHDOG_POLICY=$(miner_watchdog_policy)
STRATUM_TLS_MODE=$(normalize_stratum_tls "${STRATUM_TLS:-auto}")
export_pearl_batched_hash_threads "${PEARL_BATCHED_HASH_THREADS:-${RGM_PEARL_BATCHED_HASH_THREADS:-}}"
RGMINER_DISABLED_GPU_FILE="${RGMINER_DISABLED_GPU_FILE:-${SCRIPT_DIR}/rgminer_disabled_gpus}"
export RGMINER_DISABLED_GPU_FILE
mkdir -p "$(dirname "$RGMINER_DISABLED_GPU_FILE")" 2>/dev/null || true
touch "$RGMINER_DISABLED_GPU_FILE" 2>/dev/null || true

ARGS=(
  --algo "$MINER_ALGO"
)
if [[ -n "$ADDRESS" ]]; then
  ARGS+=(--address "$ADDRESS")
fi
ARGS+=(
  --api-host "$API_HOST"
  --api-port "$API_PORT"
  --worker-name "$WORKER_NAME"
  "--watchdog=${MINER_WATCHDOG_POLICY}"
)

if [[ -n "$POOLS_VALUE" ]]; then
  append_endpoint_args "$POOLS_VALUE" ""
fi

if [[ -n "${STRATUM_PASS:-}" ]]; then
  ARGS+=(--stratum-pass "$STRATUM_PASS")
fi
case "$STRATUM_TLS_MODE" in
  tls|verify) ARGS+=(--stratum-tls) ;;
  tcp) ;; # Explicit plaintext URLs were produced by append_endpoint_args.
  insecure)
    echo "[h-run] ERROR: release miner requires TLS certificate verification; STRATUM_TLS=insecure is unsupported" >&2
    exit 1
    ;;
esac
if [[ -n "${PROTO:-}" ]]; then
  ARGS+=(--proto "$PROTO")
elif [[ "$MINER_ALGO" == "pearl" && -n "${PEARL_PROTOCOL:-}" ]]; then
  ARGS+=(--proto "$PEARL_PROTOCOL")
fi
if [[ -n "${CCLOCK:-}" ]]; then
  ARGS+=(--cclock "$CCLOCK")
fi
if [[ -n "${MCLOCK:-}" ]]; then
  ARGS+=(--mclock "$MCLOCK")
fi
if [[ -n "${LOCK_CCLOCK:-}" ]]; then
  ARGS+=(--lock-cclock "$LOCK_CCLOCK")
fi
if [[ -n "${LOCK_MCLOCK:-}" ]]; then
  ARGS+=(--lock-mclock "$LOCK_MCLOCK")
fi
if [[ -n "${PL:-}" ]]; then
  ARGS+=(--pl "$PL")
fi
if [[ -n "${OC_DISPLAY:-}" ]]; then
  ARGS+=(--oc-display "$OC_DISPLAY")
fi
if bool_enabled "${PLAIN_CONSOLE:-0}"; then
  ARGS+=(--plain-console)
fi

append_extra_args "${EXTRA_ARGS:-}"
append_pearl_share_diff_args "${PEARL_SHARE_DIFF:-${RGM_PEARL_SHARE_DIFF:-${RGMINER_PEARL_SHARE_DIFF:-}}}"
validate_and_append_devices "${DEVICES:-}"
rg_driver_ensure_open

{
  echo "Launching rgminer with:"
  echo "ALGO: $MINER_ALGO"
  echo "ADDRESS: $ADDRESS"
  echo "WORKER_NAME: $WORKER_NAME"
  echo "STRATUM: ${POOLS_VALUE}"
  echo "DEVICES: ${DEVICES:-all}"
  echo "WATCHDOG_POLICY: ${WATCHDOG_POLICY_NORMALIZED}"
  echo "MINER_WATCHDOG_POLICY: ${MINER_WATCHDOG_POLICY}"
  echo "STRATUM_TLS: ${STRATUM_TLS_MODE}"
  echo "PEARL_PROTOCOL: ${PEARL_PROTOCOL:-auto}"
  echo "CCLOCK: ${CCLOCK:-unchanged}"
  echo "MCLOCK: ${MCLOCK:-unchanged}"
  echo "LOCK_CCLOCK: ${LOCK_CCLOCK:-unchanged}"
  echo "LOCK_MCLOCK: ${LOCK_MCLOCK:-unchanged}"
  echo "PL: ${PL:-unchanged}"
  echo "OC_DISPLAY: ${OC_DISPLAY:-DISPLAY-or-:0}"
  echo "PEARL_BATCHED_HASH_THREADS: ${PEARL_BATCHED_HASH_THREADS:-${RGM_PEARL_BATCHED_HASH_THREADS:-default}}"
  echo "PEARL_SHARE_DIFF: ${PEARL_SHARE_DIFF:-${RGM_PEARL_SHARE_DIFF:-${RGMINER_PEARL_SHARE_DIFF:-default-auto}}}"
  echo "INSTALL_CMP_DRIVER: ${INSTALL_CMP_DRIVER}"
  echo "DISABLED_GPU_FILE: ${RGMINER_DISABLED_GPU_FILE}"
  echo "BACKEND: ${RGMINER_BACKEND:-compiled launcher default}"
  printf 'ARGS:'
  printf ' %q' "${ARGS[@]}"
  printf '\n'
} >"$LOG_FILE"

cd "$SCRIPT_DIR"
miner_pid=""
api_error_watcher_pid=""
unlocker_watcher_pid=""
forward_miner_signal() {
  local signal="$1"
  local exit_code="$2"
  trap - INT TERM
  stop_unlocker_watcher
  if [[ -n "$miner_pid" ]] && kill -0 "$miner_pid" 2>/dev/null; then
    kill -"$signal" "$miner_pid" 2>/dev/null || true
    wait "$miner_pid" 2>/dev/null || true
  fi
  if [[ -n "$api_error_watcher_pid" ]] &&
     kill -0 "$api_error_watcher_pid" 2>/dev/null; then
    kill -TERM "$api_error_watcher_pid" 2>/dev/null || true
    wait "$api_error_watcher_pid" 2>/dev/null || true
  fi
  exit "$exit_code"
}
trap 'forward_miner_signal TERM 143' TERM
trap 'forward_miner_signal INT 130' INT
cleanup_reboot_receipt() {
  if [[ -n "${Q_8a7be0c930b54fca91ad:-}" ]]; then
    rm -f -- "$Q_8a7be0c930b54fca91ad"
    unset Q_8a7be0c930b54fca91ad
  fi
}
trap cleanup_reboot_receipt EXIT
while true; do
  # Fresh receipt prevents a previous miner run from acknowledging this reboot.
  unset Q_8a7be0c930b54fca91ad
  if ! bool_enabled "${HIVE_MESSAGE_DISABLE:-0}"; then
    Q_8a7be0c930b54fca91ad=$(mktemp /tmp/rgminer-reboot-receipt.XXXXXX) || Q_8a7be0c930b54fca91ad=""
    if [[ -n "$Q_8a7be0c930b54fca91ad" ]]; then
      printf 0 > "$Q_8a7be0c930b54fca91ad"
      export Q_8a7be0c930b54fca91ad
    fi
  fi
  set +e
  RGMINER_BACKEND="${RGMINER_BACKEND-}" ./rgminer "${ARGS[@]}" &
  miner_pid=$!
  watch_api_errors "$miner_pid" &
  api_error_watcher_pid=$!
  watch_unlocker_status "$miner_pid" &
  unlocker_watcher_pid=$!
  wait "$miner_pid"
  miner_status=$?
  stop_unlocker_watcher
  cleanup_reboot_receipt
  miner_pid=""
  if kill -0 "$api_error_watcher_pid" 2>/dev/null; then
    kill -TERM "$api_error_watcher_pid" 2>/dev/null || true
  fi
  wait "$api_error_watcher_pid" 2>/dev/null || true
  api_error_watcher_pid=""
  set -e
  if [[ "$miner_status" -eq 42 ]]; then
    handle_watchdog_exit "rgminer" && continue
    exit "$miner_status"
  fi
  exit "$miner_status"
done
