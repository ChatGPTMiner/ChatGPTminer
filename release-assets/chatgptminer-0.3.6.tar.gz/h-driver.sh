#!/usr/bin/env bash
# Hive-only preflight, sourced before the compiled launcher starts.

rg_driver_cmp_buses() {
  local path vendor device
  for path in /sys/bus/pci/devices/*; do
    [[ -r "$path/vendor" && -r "$path/device" ]] || continue
    read -r vendor <"$path/vendor"
    [[ "$vendor" == 0x10de ]] || continue
    read -r device <"$path/device"
    # Same detection IDs as detect_cmp_stockflow_devices() in the unlocker.
    case "$device" in
      0x1f0b|0x1e09|0x248a|0x220d|0x20c2|0x2082)
        printf '%s\n' "${path##*/}" ;;
    esac
  done
  return 0
}

rg_driver_module_info() { cat /proc/driver/nvidia/version 2>/dev/null; }
rg_driver_gpu_inventory() {
  nvidia-smi --query-gpu=uuid,driver_version,pci.bus_id --format=csv,noheader
}
rg_driver_compute_processes() {
  nvidia-smi --query-compute-apps=pid --format=csv,noheader,nounits
}
rg_driver_lock_path() { printf '/run/lock/rgminer-nvidia-driver-update.lock\n'; }

rg_driver_notify() {
  local severity="$1" text="$2" messenger
  printf '[RG] %s\n' "$text" >&2
  case "${HIVE_MESSAGE_DISABLE:-0}" in 1|true|yes|on) return 0 ;; esac
  messenger=$(command -v message || true)
  [[ ! -x /hive/bin/message ]] || messenger=/hive/bin/message
  [[ -n "$messenger" ]] || return 0
  timeout 55 "$messenger" "$severity" "[RG] $text" 9>&- || true
}

rg_driver_version() {
  local info="$1"
  info="${info%%$'\n'*}"
  if [[ "$info" =~ [[:space:]]([0-9]{3}\.[0-9]{2,3}(\.[0-9]{2})?) ]]; then
    printf '%s\n' "${BASH_REMATCH[1]}"
  fi
}

rg_driver_check_gpus() {
  local required="$1" before="${2:-}" inventory uuid version bus extra row
  local seen=$'\n' identities=$'\n'
  inventory=$(rg_driver_gpu_inventory 2>&1) || {
    printf 'nvidia-smi cannot communicate with the driver: %s\n' "$inventory"
    return 1
  }
  [[ -n "$inventory" ]] || { echo 'nvidia-smi reports no GPUs'; return 1; }
  while IFS= read -r row; do
    IFS=, read -r uuid version bus extra <<<"$row"
    uuid="${uuid//[[:space:]]/}"; version="${version//[[:space:]]/}"
    bus="${bus//[[:space:]]/}"
    if [[ ! "$uuid" =~ ^GPU-[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$ ||
          "$version" != 610.43.03 || -n "$extra" ||
          ! "$bus" =~ ^([0-9a-fA-F]{4}|[0-9a-fA-F]{8}):[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-7]$ ]]; then
      printf 'Invalid GPU inventory or driver version mismatch: %s\n' "$row"
      return 1
    fi
    bus="${bus,,}"
    if [[ "$seen" == *$'\n'"${bus: -12}"$'\n'* || "$identities" == *$'\n'"$uuid,"* ]]; then
      printf 'Duplicate GPU UUID or PCI bus in nvidia-smi: %s\n' "$row"
      return 1
    fi
    seen+="${bus: -12}"$'\n'
    identities+="$uuid,${bus: -12}"$'\n'
  done <<<"$inventory"
  while IFS= read -r bus; do
    [[ "$seen" == *$'\n'"${bus,,}"$'\n'* ]] || {
      printf 'CMP GPU PCI %s is missing from nvidia-smi\n' "$bus"
      return 1
    }
  done <<<"$required"
  # Preserve other NVIDIA cards on a mixed rig as well as the CMP targets.
  while IFS=, read -r uuid version bus extra; do
    uuid="${uuid//[[:space:]]/}"; bus="${bus//[[:space:]]/}"; bus="${bus,,}"
    [[ "$uuid" == GPU-* && "$bus" == *:*:*.* ]] || continue
    [[ "$identities" == *$'\n'"$uuid,${bus: -12}"$'\n'* ]] || {
      printf 'Previously visible GPU %s PCI %s is missing after installation\n' "$uuid" "$bus"
      return 1
    }
  done <<<"$before"
  return 0
}

rg_driver_run_updater() (
  # nvstop and the updater call `miner stop/start`. Here the launcher has not
  # started yet: preserve this startup screen and defer launch until postflight.
  # A short-lived marker releases any background Hive services which inherit
  # the function: their later miner commands must resume normal behavior.
  if [[ -z "${RG_HIVE_DRIVER_PREFLIGHT_GATE:-}" ]]; then
    RG_HIVE_DRIVER_PREFLIGHT_GATE=$(mktemp /tmp/rgminer-driver-startup.XXXXXX) || exit 1
    trap 'rm -f -- "$RG_HIVE_DRIVER_PREFLIGHT_GATE"' EXIT
  fi
  export RG_HIVE_DRIVER_PREFLIGHT_GATE
  miner() {
    case "${1:-}" in
      stop|start) [[ ! -f "${RG_HIVE_DRIVER_PREFLIGHT_GATE:-}" ]] || return 0 ;;
    esac
    command miner "$@"
  }
  export -f miner
  # The parent retains the lock through postflight; background services must
  # not inherit it and hold it beyond the end of this startup.
  "$@" 9>&-
)

rg_driver_failure_reason() {
  local log="$1" status="$2" detail="$3"
  if LC_ALL=C grep -Eiq 'Download error|unable to resolve|could not resolve|connection (timed out|refused)|failed: (Connection|Network)|Network is unreachable|TLS.*(failed|error)|SSL.*(failed|error)|ERROR [45][0-9][0-9]|Read error at byte|Connection reset|curl: \((6|7|18|28|35|56)\)' "$log"; then
    printf 'Driver download/connectivity error (updater exit %s). %s' "$status" "$detail"
  else
    printf 'Driver installation/load verification failed (updater exit %s). %s' "$status" "$detail"
  fi
}

rg_driver_verify_install() {
  local buses="$1" before="$2" log="$3" status="$4"
  local info actual detail reason gpu_detail gpu_status=0
  # NVML may load the newly installed module on a headless rig. Probe it before
  # reading /proc, rather than rejecting a not-yet-loaded successful install.
  gpu_detail=$(rg_driver_check_gpus "$buses" "$before") || gpu_status=$?
  info=$(rg_driver_module_info || true)
  actual=$(rg_driver_version "$info")
  detail=''
  if [[ "$info" != *'NVRM version: NVIDIA UNIX Open Kernel Module'* || "$actual" != 610.43.03 ]]; then
    detail="Expected loaded NVIDIA 610.43.03 Open; actual module: ${info%%$'\n'*}."
  elif (( gpu_status != 0 )); then
    detail="$gpu_detail"
  else
    return 0
  fi
  reason=$(rg_driver_failure_reason "$log" "$status" "$detail")
  rg_driver_notify danger "$reason See $log and /var/log/nvidia-installer.log."
  return 1
}

rg_driver_install_open() (
  local buses="$1" info="$2" updater log status=0 actual processes before
  local RG_HIVE_DRIVER_PREFLIGHT_GATE
  updater=$(command -v nvidia-driver-update || true)
  if [[ -z "$updater" || ! -x "$updater" ]]; then
    rg_driver_notify danger 'nvidia-driver-update is unavailable; cannot install NVIDIA 610.43.03 Open for CMP GPUs.'
    return 1
  fi
  # Hive's nvstop uses rmmod -f. The startup-screen preservation below must
  # never leave running compute work behind during that forced unload.
  if ! processes=$(rg_driver_compute_processes 2>&1); then
    rg_driver_notify danger "Cannot check running NVIDIA compute processes before installation: $processes"
    return 1
  fi
  if [[ -n "${processes//[[:space:]]/}" ]]; then
    rg_driver_notify danger "NVIDIA compute processes are still running ($processes); stop them before installing NVIDIA 610.43.03 Open."
    return 1
  fi
  before=$(rg_driver_gpu_inventory 2>/dev/null || true)
  log=$(mktemp /tmp/rgminer-nvidia-driver-610.43.03.XXXXXX.log) || return 1
  RG_HIVE_DRIVER_PREFLIGHT_GATE=$(mktemp /tmp/rgminer-driver-startup.XXXXXX) || return 1
  trap 'rm -f -- "$RG_HIVE_DRIVER_PREFLIGHT_GATE"' EXIT
  actual=$(rg_driver_version "$info")
  rg_driver_notify warning "Unsuitable NVIDIA driver (${actual:-unknown} legacy) detected for CMP GPUs. Installing NVIDIA 610.43.03 Open."
  # Official 610 defaults to Open (README/kernel_open.html). Hive's updater
  # accepts a URL but does not forward --kernel-module-type to the installer.
  if rg_driver_run_updater "$updater" \
      https://download.nvidia.com/XFree86/Linux-x86_64/610.43.03/NVIDIA-Linux-x86_64-610.43.03.run \
      --force 2>&1 | tee "$log"; then
    status=0
  else
    status=${PIPESTATUS[0]}
  fi
  rg_driver_verify_install "$buses" "$before" "$log" "$status"
)

rg_driver_ensure_open() (
  local buses info lock
  buses=$(rg_driver_cmp_buses) || return 1
  [[ -n "$buses" ]] || return 0
  info=$(rg_driver_module_info || true)
  [[ "$info" != *'NVRM version: NVIDIA UNIX Open Kernel Module'* ]] || return 0
  lock=$(rg_driver_lock_path)
  exec 9>"$lock" || return 1
  flock -x 9 || return 1
  # Another startup may have completed the installation while we waited.
  info=$(rg_driver_module_info || true)
  [[ "$info" != *'NVRM version: NVIDIA UNIX Open Kernel Module'* ]] || return 0
  if [[ "$info" != *'NVRM version: NVIDIA UNIX x86_64 Kernel Module'* ]]; then
    rg_driver_notify danger 'Cannot determine the loaded NVIDIA kernel module for CMP GPUs; installation was not started.'
    return 1
  fi
  rg_driver_install_open "$buses" "$info"
)
