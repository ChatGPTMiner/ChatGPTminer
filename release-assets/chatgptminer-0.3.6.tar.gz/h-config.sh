#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
source "$SCRIPT_DIR/h-manifest.conf"

trim_value() {
  local value="${1-}"
  value="${value#"${value%%[![:space:]]*}"}"
  value="${value%"${value##*[![:space:]]}"}"
  printf '%s' "$value"
}

normalize_algo() {
  local value="${1:-}"
  value="${value,,}"
  case "$value" in
    pearl|prl|pearlhash|pearl-hash|pearl_hash)
      printf 'pearl'
      ;;
    exfer|argon2id|exfer_argon2id|exfer-argon2|exfer-argon2id)
      printf 'exfer-argon2id'
      ;;
    quantus|qtc|poseidon2|poseidon-2|poseidon_2)
      printf 'quantus'
      ;;
    zkpow|zk|nock|nockchain|nock-zk|nock_zk|nock-zk-v5)
      printf 'nock-zk'
      ;;
    "")
      printf 'pearl'
      ;;
    *)
      printf '%s' "$value"
      ;;
  esac
}

bool_enabled() {
  local raw="${1:-}"
  local value="${raw,,}"
  [[ "$value" =~ ^(1|true|yes|on|y|enable|enabled)$ ]]
}

bool_disabled() {
  local raw="${1:-}"
  local value="${raw,,}"
  [[ "$value" =~ ^(0|false|no|off|n|disable|disabled)$ ]]
}

normalize_install_cmp_driver() {
  local raw="${1:-}"
  raw=$(trim_value "$raw")
  if bool_disabled "$raw" || [[ -z "$raw" ]]; then
    printf '0'
    return
  fi
  case "$raw" in
    580.159.03|580.159.04|580.173.02|580.178.04|590.48.01|595.58.03|595.71.05|595.80|595.84|595.91.07|610.43.03)
      printf '%s' "$raw"
      ;;
    *)
      echo "WARNING: ignoring invalid install_cmp_driver value '$raw'; expected an exact supported driver version or 0" >&2
      printf '0'
      ;;
  esac
}

normalize_watchdog_policy() {
  local raw="${1:-}"
  local value
  raw=$(trim_value "$raw")
  value="${raw,,}"
  case "$value" in
    restart|restarting)
      printf 'restart'
      ;;
    reboot|rebooting)
      printf 'reboot'
      ;;
    notify|message|message-only|log|log-only|none|off|0|false|no|disable|disabled|"")
      printf 'notify'
      ;;
    *)
      echo "WARNING: ignoring invalid watchdog-policy value '$raw'; using restart" >&2
      printf 'restart'
      ;;
  esac
}

apply_watchdog_policy_to_compat_flag() {
  case "$WATCHDOG_POLICY" in
    restart|reboot)
      WATCHDOG=1
      ;;
    *)
      WATCHDOG=0
      ;;
  esac
}

write_var() {
  local name="$1"
  local value="${2-}"
  printf '%s=' "$name" >>"$CONFIG_FILE"
  printf '%q\n' "$value" >>"$CONFIG_FILE"
}

write_var_if_set() {
  local name="$1"
  local value="${2-}"
  [[ -n "$value" ]] || return 0
  write_var "$name" "$value"
}

read_existing_config_value() {
  local name="$1"
  local line=""
  [[ -f "$CONFIG_FILE" ]] || return 0
  while IFS= read -r line; do
    case "$line" in
      "$name"=*|export\ "$name"=*)
        line="${line#export }"
        printf '%s\n' "${line#*=}"
        ;;
    esac
  done <"$CONFIG_FILE" | tail -n1
}

normalize_pearl_batched_hash_threads() {
  local raw="${1:-}"
  raw=$(trim_value "$raw")
  # Hive may preserve an empty UI field as '' and an existing shell-escaped
  # empty value as ''''. Both mean unset, not an invalid thread count.
  if [[ "$raw" =~ ^[\'\"]*$ ]]; then
    raw=""
  elif [[ ${#raw} -ge 2 &&
          (( "${raw:0:1}" == "'" && "${raw: -1}" == "'" ) ||
           ( "${raw:0:1}" == '"' && "${raw: -1}" == '"' )) ]]; then
    raw="${raw:1:${#raw}-2}"
  fi
  case "$raw" in
    ""|auto|AUTO|Auto|64|128|256|512|1024)
      if [[ "${raw,,}" == "auto" ]]; then
        printf 'auto'
      else
        printf '%s' "$raw"
      fi
      ;;
    *)
      echo "WARNING: ignoring invalid pearl batched hash threads '$raw'; expected auto, 64, 128, 256, 512, or 1024" >&2
      printf ''
      ;;
  esac
}

normalize_pearl_share_diff() {
  local raw="${1:-}"
  local value
  raw=$(trim_value "$raw")
  value="${raw,,}"
  case "$value" in
    "")
      printf ''
      ;;
    auto)
      printf 'auto'
      ;;
    off|none|disable|disabled|false|0|no)
      printf 'off'
      ;;
    *)
      if [[ "$raw" =~ ^[1-9][0-9]*$ ]]; then
        printf '%s' "$raw"
      else
        echo "WARNING: ignoring invalid pearl share diff '$raw'; expected auto, off, or positive integer" >&2
        printf ''
      fi
      ;;
  esac
}

normalize_stratum_tls() {
  local raw="${1:-}"
  local value
  raw=$(trim_value "$raw")
  value="${raw,,}"
  case "$value" in
    ""|auto)
      printf 'auto'
      ;;
    tls|ssl|on|true|1)
      printf 'tls'
      ;;
    tcp|off|false|0)
      printf 'tcp'
      ;;
    verify|tls-verify)
      printf 'verify'
      ;;
    insecure|tls-insecure)
      printf 'insecure'
      ;;
    *)
      echo "WARNING: ignoring invalid STRATUM_TLS '$raw'; using auto" >&2
      printf 'auto'
      ;;
  esac
}

append_pool() {
  local raw="${1-}"
  local token
  raw="${raw//,/ }"
  raw="${raw//;/ }"
  for token in $raw; do
    token=$(trim_value "$token")
    [[ -n "$token" ]] && POOLS+=("$token")
  done
}

apply_wallet_worker_suffix() {
  local raw base suffix
  raw=$(trim_value "$ADDRESS")
  [[ "$raw" == *.* ]] || return 0
  base="${raw%.*}"
  suffix="${raw##*.}"
  [[ -n "$base" && -n "$suffix" ]] || return 0
  ADDRESS="$base"
  if (( WORKER_NAME_EXPLICIT == 0 )); then
    WORKER_NAME_VALUE="$suffix"
  fi
}

CONFIG_FILE="${RGMINER_CONFIG:-${SCRIPT_DIR}/config.env}"
mkdir -p "$(dirname "$CONFIG_FILE")"

EXISTING_PEARL_BATCHED_HASH_THREADS=$(read_existing_config_value PEARL_BATCHED_HASH_THREADS)
if [[ -z "$EXISTING_PEARL_BATCHED_HASH_THREADS" ]]; then
  EXISTING_PEARL_BATCHED_HASH_THREADS=$(read_existing_config_value RGM_PEARL_BATCHED_HASH_THREADS)
fi
WORKER_NAME_VALUE=$(trim_value "${CUSTOM_WORKER_NAME:-${RGMINER_WORKER_NAME:-${WORKER_NAME:-${RIG_NAME:-}}}}")
WORKER_NAME_EXPLICIT=0
if [[ -n "$WORKER_NAME_VALUE" ]]; then
  WORKER_NAME_EXPLICIT=1
fi
if [[ -z "$WORKER_NAME_VALUE" ]]; then
  WORKER_NAME_VALUE=$(hostname 2>/dev/null || printf 'rgminer')
fi

ADDRESS=$(trim_value "${CUSTOM_TEMPLATE:-${CUSTOM_WALLET:-}}")

FLIGHT_SHEET_ALGO=$(trim_value "${CUSTOM_ALGO:-}")
ALGO=$(normalize_algo "${FLIGHT_SHEET_ALGO:-pearl}")
STATS_ALGO="$FLIGHT_SHEET_ALGO"
if [[ -z "$STATS_ALGO" ]]; then
  if [[ "$ALGO" == "pearl" ]]; then
    STATS_ALGO="pearlhash"
  else
    STATS_ALGO="$ALGO"
  fi
fi
API_HOST=$(trim_value "${CUSTOM_API_HOST:-${API_HOST:-127.0.0.1}}")
[[ -n "$API_HOST" ]] || API_HOST="127.0.0.1"
API_PORT="${CUSTOM_API_PORT:-9200}"
STRATUM_PASS=$(trim_value "${CUSTOM_STRATUM_PASS:-${STRATUM_PASS:-}}")
STRATUM_TLS=$(normalize_stratum_tls "${CUSTOM_STRATUM_TLS:-${STRATUM_TLS:-auto}}")
PEARL_PROTOCOL=$(trim_value "${CUSTOM_PEARL_PROTOCOL:-${PEARL_PROTOCOL:-}}")
PROTO=$(trim_value "${CUSTOM_PROTO:-${PROTO:-}}")
CCLOCK=$(trim_value "${CUSTOM_CCLOCK:-${CCLOCK:-}}")
MCLOCK=$(trim_value "${CUSTOM_MCLOCK:-${MCLOCK:-}}")
LOCK_CCLOCK=$(trim_value "${CUSTOM_LOCK_CCLOCK:-${LOCK_CCLOCK:-}}")
LOCK_MCLOCK=$(trim_value "${CUSTOM_LOCK_MCLOCK:-${LOCK_MCLOCK:-}}")
PL=$(trim_value "${CUSTOM_PL:-${PL:-}}")
OC_DISPLAY=$(trim_value "${CUSTOM_OC_DISPLAY:-${OC_DISPLAY:-}}")
PLAIN_CONSOLE=$(trim_value "${CUSTOM_PLAIN_CONSOLE:-${PLAIN_CONSOLE:-0}}")
WATCHDOG="${CUSTOM_WATCHDOG:-0}"
WATCHDOG_POLICY=$(trim_value "${CUSTOM_WATCHDOG_POLICY:-${WATCHDOG_POLICY:-${RGM_WATCHDOG_POLICY:-${RGMINER_WATCHDOG_POLICY:-}}}}")
WATCHDOG_POLICY_EXPLICIT=0
if [[ -n "$WATCHDOG_POLICY" ]]; then
  WATCHDOG_POLICY_EXPLICIT=1
fi
PEARL_BATCHED_HASH_THREADS=$(normalize_pearl_batched_hash_threads "${CUSTOM_PEARL_BATCHED_HASH_THREADS:-${CUSTOM_RGM_PEARL_BATCHED_HASH_THREADS:-${PEARL_BATCHED_HASH_THREADS:-${RGM_PEARL_BATCHED_HASH_THREADS:-${RGMINER_PEARL_BATCHED_HASH_THREADS:-${EXISTING_PEARL_BATCHED_HASH_THREADS:-}}}}}}")
PEARL_SHARE_DIFF=$(normalize_pearl_share_diff "${CUSTOM_PEARL_SHARE_DIFF:-${PEARL_SHARE_DIFF:-${RGM_PEARL_SHARE_DIFF:-${RGMINER_PEARL_SHARE_DIFF:-}}}}")
INSTALL_CMP_DRIVER=$(normalize_install_cmp_driver "${CUSTOM_INSTALL_CMP_DRIVER:-${INSTALL_CMP_DRIVER:-0}}")
EXTRA_ARGS=()
POOLS=()
DEVICES=()

append_pool "${CUSTOM_URL:-}"

if [[ -n "${CUSTOM_PASS:-}" && "${CUSTOM_PASS}" == *:* ]]; then
  append_pool "$CUSTOM_PASS"
fi

TOKENS=()
if [[ -n "${CUSTOM_USER_CONFIG:-}" ]]; then
  # Hive custom config is expected to be shell-like whitespace separated.
  # Preserve long miner options and their values without maintaining a wrapper
  # whitelist. Dedicated Hive fields above still provide the default command.
  # read consumes only one line. Normalize LF/CRLF so every User Config
  # line contributes literal arguments without evaluating shell input.
  USER_CONFIG_TEXT="${CUSTOM_USER_CONFIG//$'\r'/ }"
  USER_CONFIG_TEXT="${USER_CONFIG_TEXT//$'\n'/ }"
  read -r -a TOKENS <<<"$USER_CONFIG_TEXT"
fi

for ((i = 0; i < ${#TOKENS[@]}; ++i)); do
  token="${TOKENS[$i]}"

  case "$token" in
    --proto=*)
      PROTO=$(trim_value "${token#*=}")
      continue
      ;;
    --proto)
      if ((i + 1 >= ${#TOKENS[@]})) || [[ "${TOKENS[$((i + 1))]}" == --* ]]; then
        echo "WARNING: --proto requires a protocol name; ignoring it" >&2
        continue
      fi
      i=$((i + 1))
      PROTO=$(trim_value "${TOKENS[$i]}")
      continue
      ;;
    --install_cmp_driver=*)
      INSTALL_CMP_DRIVER=$(normalize_install_cmp_driver "${token#*=}")
      continue
      ;;
    --install_cmp_driver)
      if ((i + 1 >= ${#TOKENS[@]})); then
        echo "WARNING: --install_cmp_driver requires an exact supported driver version or 0; using 0" >&2
        INSTALL_CMP_DRIVER=0
      else
        i=$((i + 1))
        INSTALL_CMP_DRIVER=$(normalize_install_cmp_driver "${TOKENS[$i]}")
      fi
      continue
      ;;
    PEARL_BATCHED_HASH_THREADS=*|RGM_PEARL_BATCHED_HASH_THREADS=*)
      PEARL_BATCHED_HASH_THREADS=$(normalize_pearl_batched_hash_threads "${token#*=}")
      continue
      ;;
    PEARL_SHARE_DIFF=*|RGM_PEARL_SHARE_DIFF=*|RGMINER_PEARL_SHARE_DIFF=*|CUSTOM_PEARL_SHARE_DIFF=*)
      PEARL_SHARE_DIFF=$(normalize_pearl_share_diff "${token#*=}")
      continue
      ;;
  esac

  case "$token" in
    --)
      for ((j = i + 1; j < ${#TOKENS[@]}; ++j)); do
        EXTRA_ARGS+=("${TOKENS[$j]}")
      done
      break
      ;;
    -d)
      EXTRA_ARGS+=("$token")
      if ((i + 1 >= ${#TOKENS[@]})); then
        echo "WARNING: -d requires a GPU index or comma-separated list" >&2
        break
      fi
      i=$((i + 1))
      EXTRA_ARGS+=("${TOKENS[$i]}")
      ;;
    -d=*)
      EXTRA_ARGS+=("$token")
      ;;
    --no-cmp-unlock)
      EXTRA_ARGS+=("$token")
      ;;
    --*)
      EXTRA_ARGS+=("$token")
      if [[ "$token" != --*=* ]] && ((i + 1 < ${#TOKENS[@]})) &&
          [[ "${TOKENS[$((i + 1))]}" != --* ]]; then
        i=$((i + 1))
        EXTRA_ARGS+=("${TOKENS[$i]}")
      fi
      ;;
  esac
done

# The flight-sheet algorithm is a HiveOS display label. When User Config
# supplies a miner algorithm, use its final value for the canonical command as
# well so an unsupported display label is never validated by the miner first.
for ((i = 0; i < ${#EXTRA_ARGS[@]}; ++i)); do
  token="${EXTRA_ARGS[$i]}"
  case "${token,,}" in
    --algo=*|--algorithm=*)
      ALGO=$(normalize_algo "${token#*=}")
      ;;
    --algo|--algorithm)
      if ((i + 1 < ${#EXTRA_ARGS[@]})); then
        ALGO=$(normalize_algo "${EXTRA_ARGS[$((i + 1))]}")
        i=$((i + 1))
      fi
      ;;
  esac
done

if [[ "$ALGO" == "quantus" ]]; then
  STATS_ALGO=quantus
elif [[ "$ALGO" == "nock-zk" ]]; then
  STATS_ALGO=zkpow
fi

# Hive flight sheets may keep a legacy display label (for example `qubic`)
if [[ -z "$WATCHDOG_POLICY" ]]; then
  WATCHDOG_POLICY=restart
else
  WATCHDOG_POLICY=$(normalize_watchdog_policy "$WATCHDOG_POLICY")
fi
apply_watchdog_policy_to_compat_flag

ADDRESS=${ADDRESS//%WORKER_NAME%/${WORKER_NAME_VALUE}}
ADDRESS=${ADDRESS//%WORKER_ID%/${WORKER_ID:-}}
ADDRESS=${ADDRESS//%FARM_ID%/${FARM_ID:-}}
apply_wallet_worker_suffix

: >"$CONFIG_FILE"
write_var ADDRESS "$ADDRESS"
write_var POOLS "${POOLS[*]}"
write_var API_HOST "$API_HOST"
write_var API_PORT "$API_PORT"
write_var STRATUM_PASS "$STRATUM_PASS"
write_var STRATUM_TLS "$STRATUM_TLS"
write_var PEARL_PROTOCOL "$PEARL_PROTOCOL"
write_var PROTO "$PROTO"
write_var CCLOCK "$CCLOCK"
write_var MCLOCK "$MCLOCK"
write_var LOCK_CCLOCK "$LOCK_CCLOCK"
write_var LOCK_MCLOCK "$LOCK_MCLOCK"
write_var PL "$PL"
write_var OC_DISPLAY "$OC_DISPLAY"
write_var PLAIN_CONSOLE "$PLAIN_CONSOLE"
write_var WORKER_NAME "$WORKER_NAME_VALUE"
write_var DEVICES "${DEVICES[*]}"
write_var STATS_ALGO "$STATS_ALGO"
write_var ALGO "$ALGO"
write_var WATCHDOG "$WATCHDOG"
write_var WATCHDOG_POLICY "$WATCHDOG_POLICY"
write_var PEARL_BATCHED_HASH_THREADS "$PEARL_BATCHED_HASH_THREADS"
write_var PEARL_SHARE_DIFF "$PEARL_SHARE_DIFF"
write_var INSTALL_CMP_DRIVER "$INSTALL_CMP_DRIVER"
write_var EXTRA_ARGS "${EXTRA_ARGS[*]}"

echo "Wrote $CONFIG_FILE"
